package com.example.rasmus.tryin.UI;

import android.app.Activity;
import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ScrollView;
import android.widget.TextView;

import com.example.rasmus.tryin.R;
import com.example.rasmus.tryin.random.RecipeTest;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    static private int layoutCounter = 0;
    private List<MealFragment> mealFragmentList = new ArrayList<>();

    // Temporary
    private RecipeTest recipe = new RecipeTest();

    ScrollView scrollView;
    TextView textCalories;

    int todaysGoal = 2500;
    int todaysCalories = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Today's Meals");

        intializeTodaysRecipe();


        textCalories = (TextView) findViewById(R.id.text_calories);
        updateCalorieText();

        scrollView = (ScrollView) findViewById(R.id.scrollView1);

        // Setting up the add button
        final FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab_1);
        fab.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, PickMealActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivityForResult(intent, 0);
            }
        });

        // Create a bundle of information
        int startID = R.id.layout_1;
        for (int i = 0; i < recipe.getIdCounter(); i++) {
            Bundle bundle = new Bundle();
            final MealFragment mealFragment = new MealFragment();
            FragmentManager manager = getSupportFragmentManager();
            bundle.putInt("img", recipe.getImgID(i));
            bundle.putInt("calories", recipe.getCalories(i));
            bundle.putString("meal", recipe.getMealName(i));
            mealFragment.setArguments(bundle);
            mealFragmentList.add(mealFragment);
            manager.beginTransaction()
                    .replace(startID + i, mealFragment, mealFragment.getTag())
                    .commit();
            layoutCounter++;
        }
    }


    public void createMeal() {

        // Create a bundle of information
        int startID = R.id.layout_1;


        final MealFragment mealFragment = new MealFragment();
        Bundle bundle = new Bundle();
        FragmentManager manager = getSupportFragmentManager();
        bundle.putInt("img", recipe.getLastImgID());
        bundle.putInt("calories", recipe.getLastCalories());
        bundle.putString("meal", recipe.getLastMealName());
        mealFragment.setArguments(bundle);
        //mealFragmentList.add(mealFragment);
        manager.beginTransaction()
                .replace(startID + layoutCounter, mealFragment, mealFragment.getTag())
                .commit();

        layoutCounter++;

        // Scroll down
        scrollView.postDelayed(new Runnable() {
            @Override
            public void run() {
                scrollView.fullScroll(ScrollView.FOCUS_DOWN);
            }
        }, 250);
    }

    public void updateCalorieText(){
        // Setting up the text at the top of the front screen
        int sum = 0;
        for(int i = 0; i < recipe.getIdCounter(); i++){
            sum += recipe.getCalories(i);
            System.out.println(recipe.getCalories(i));
        }
        todaysCalories = sum;
        String calories = "Calories: " + todaysCalories + " / " + todaysGoal;
        textCalories.setText(calories);
    }


    public void intializeTodaysRecipe(){
        recipe.addRecipe(R.drawable.breakfast, 650, "Breakfast");
        recipe.addRecipe(R.drawable.lunch, 760, "Lunch");
        recipe.addRecipe(R.drawable.dinner, 1000, "Dinner");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 0) {
            if (resultCode == Activity.RESULT_OK) {
                String res = data.getStringExtra("meal");
                switch (res){
                    case "Breakfast":
                        recipe.addRecipe(R.drawable.breakfast, 650, "Breakfast");
                        break;

                    case "Lunch":
                        recipe.addRecipe(R.drawable.lunch, 760, "Lunch");
                        break;

                    case "Dinner":
                        recipe.addRecipe(R.drawable.dinner, 1000, "Dinner");
                        break;

                    default:
                        // Something went wrong
                }

                createMeal();
                updateCalorieText();
            }
        }
    }
}


