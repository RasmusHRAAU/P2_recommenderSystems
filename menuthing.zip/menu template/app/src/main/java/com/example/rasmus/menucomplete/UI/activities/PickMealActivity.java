package com.example.rasmus.menucomplete.UI.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.rasmus.menucomplete.R;
import com.example.rasmus.menucomplete.other.RecipeTest;

public class PickMealActivity extends AppCompatActivity {
    ListView listView;
    private RecipeTest recipe = new RecipeTest();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pick_meal);

        // Get ListView object from xml
        listView = (ListView) findViewById(R.id.listview1);

        // Defined Array values to show in ListView
        final String[] values = new String[]{"Breakfast",
                "Lunch",
                "Dinner"
        };

        // Define a new Adapter
        // First parameter - Context
        // Second parameter - Layout for the row
        // Third parameter - ID of the TextView to which the data is written
        // Forth - the Array of data

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, android.R.id.text1, values);


        // Assign adapter to ListView
        listView.setAdapter(adapter);

        // ListView Item Click Listener
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {

                // ListView Clicked item value
                String itemValue = (String) listView.getItemAtPosition(position);

                switch (position) {
                    case 0:
                        recipe.addRecipe(R.drawable.breakfast, 650, "Breakfast");
                        break;

                    case 1:
                        recipe.addRecipe(R.drawable.lunch, 760, "Lunch");
                        break;

                    case 2:
                        recipe.addRecipe(R.drawable.dinner, 1000, "Dinner");
                        break;

                    default:
                        // Something went wrong
                }


                Intent intent = new Intent(PickMealActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
                overridePendingTransition(R.anim.fadein, R.anim.fadeout);

            }

        });
    }


}


