package com.example.rasmus.menucomplete.exception;

public class InvalidNumberOfMealsException extends RuntimeException {

}
