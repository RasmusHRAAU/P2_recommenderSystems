package com.example.rasmus.tryin;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.PercentFormatter;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Today's Meals");

        int todaysGoal = 2500;
        int todaysCalories = 2000;



        View hline1 = (View) findViewById(R.id.h_line_1);
        hline1.bringToFront();

        View hline2 = (View) findViewById(R.id.h_line_2);
        hline2.bringToFront();

        View hline3 = (View) findViewById(R.id.h_line_3);
        hline3.bringToFront();

        View hline4 = (View) findViewById(R.id.h_line_4);
        hline4.bringToFront();

        View hline5 = (View) findViewById(R.id.h_line_5);
        hline5.bringToFront();

        View hline6 = (View) findViewById(R.id.h_line_6);
        hline6.bringToFront();


        /*View vline1 = (View) findViewById(R.id.v_line_1);
        vline1.bringToFront();

        View vline2 = (View) findViewById(R.id.v_line_2);
        vline2.bringToFront();

        View vline3 = (View) findViewById(R.id.v_line_3);
        vline3.bringToFront();*/


        TextView textCalories = (TextView) findViewById(R.id.text_calories);
        String calories = "Calories: " + todaysCalories + " / " + todaysGoal;
        textCalories.setText(calories);


        PieChart chart1 = (PieChart) findViewById(R.id.home_chart_1);
        List<PieEntry> pieChartEntries1 = new ArrayList<>();
        pieChartEntries1.add(new PieEntry(1000, "Meal"));
        pieChartEntries1.add(new PieEntry(2500, "Total"));
        setupPieChart(chart1, pieChartEntries1);

        PieChart chart2 = (PieChart) findViewById(R.id.home_chart_2);
        List<PieEntry> pieChartEntries2 = new ArrayList<>();
        pieChartEntries2.add(new PieEntry(900, "Meal"));
        pieChartEntries2.add(new PieEntry(2500, "Total"));
        setupPieChart(chart2, pieChartEntries2);

        PieChart chart3 = (PieChart) findViewById(R.id.home_chart_3);
        List<PieEntry> pieChartEntries3 = new ArrayList<>();
        pieChartEntries3.add(new PieEntry(600, "Meal"));
        pieChartEntries3.add(new PieEntry(2500, "Total"));
        setupPieChart(chart3, pieChartEntries3);

    }

    private void setupPieChart(PieChart chart, List<PieEntry> entryList) {

        PieDataSet dataSet = new PieDataSet(entryList, "Calories");
        dataSet.setColors(ColorTemplate.createColors(new int[] = {R.color.green1, R.color.green2}));
        //dataSet.setColors(new int[] { R.color.green1, R.color.green2 }, 2);

        PieData data = new PieData(dataSet);

        chart.setData(data);
        chart.animateY(2000);
        chart.setHoleRadius(0f);
        chart.setTransparentCircleAlpha(0);
        chart.getDescription().setEnabled(false);
        chart.getLegend().setEnabled(false);

        chart.invalidate();
    }


}
