package com.example.rasmus.tryin.UI;

import android.os.Handler;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ScrollView;
import android.widget.TextView;

import com.example.rasmus.tryin.R;
import com.example.rasmus.tryin.exceptions.InvalidNumberOfMealsException;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private int layoutCounter = 0;
    private List<MealFragment> mealFragmentList = new ArrayList<>();

    // Temporary
    private RecipeTest recipe = new RecipeTest();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Today's Meals");

        // Temporary
        int todaysGoal = 2500;
        int todaysCalories = 2000;

        // Temporary solution
        for(int i = 0; i < 5; i++) {
            recipe.addRecipe(R.drawable.breakfast, 650, "Breakfast");
            recipe.addRecipe(R.drawable.lunch, 760, "Lunch");
            recipe.addRecipe(R.drawable.dinner, 1000, "Dinner");
        }


        // Setting up the text at the top of the front screen
        TextView textCalories = (TextView) findViewById(R.id.text_calories);
        String calories = "Calories: " + todaysCalories + " / " + todaysGoal;
        textCalories.setText(calories);

        final ScrollView scrollView = (ScrollView) findViewById(R.id.scrollView1);

        // Setting up the add button
        final FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab_1);
        fab.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                createMeal(scrollView);
            }
        });
    }


    public void createMeal(final ScrollView scrollView) {

        final MealFragment mealFragment = new MealFragment();
        FragmentManager manager = getSupportFragmentManager();
        mealFragmentList.add(mealFragment);

        // Create a bundle of information
        Bundle bundle = new Bundle();
        bundle.putInt("img", recipe.getImgID(layoutCounter));
        bundle.putInt("calories", recipe.getCalories(layoutCounter));
        bundle.putString("meal", recipe.getMealName(layoutCounter));

        // Send bundle to the fragment
        mealFragment.setArguments(bundle);

        switch (layoutCounter) {
            case 0:
                // Replace layout_1 from activity_main.xml with the fragment (fragment_meal.xml)
                manager.beginTransaction()
                        .replace(R.id.layout_1, mealFragment, mealFragment.getTag())
                        .commit();
                break;

            case 1:

                // Replace layout_2 from activity_main.xml with the fragment (fragment_meal.xml)
                manager.beginTransaction()
                        .replace(R.id.layout_2, mealFragment, mealFragment.getTag())
                        .commit();
                break;

            case 2:

                // Replace layout_3 from activity_main.xml with the fragment (fragment_meal.xml)
                manager.beginTransaction()
                        .replace(R.id.layout_3, mealFragment, mealFragment.getTag())
                        .commit();
                break;

            case 3:
                // Replace layout_4 from activity_main.xml with the fragment (fragment_meal.xml)
                manager.beginTransaction()
                        .replace(R.id.layout_4, mealFragment, mealFragment.getTag())
                        .commit();
                break;

            case 4:
                // Replace layout_5 from activity_main.xml with the fragment (fragment_meal.xml)
                manager.beginTransaction()
                        .replace(R.id.layout_5, mealFragment, mealFragment.getTag())
                        .commit();
                break;

            case 5:
                // Replace layout_6 from activity_main.xml with the fragment (fragment_meal.xml)
                manager.beginTransaction()
                        .replace(R.id.layout_6, mealFragment, mealFragment.getTag())
                        .commit();
                break;

            default:
                // code something
                //throw new InvalidNumberOfMealsException();
        }

        layoutCounter++;
        // Scroll down
        scrollView.postDelayed(new Runnable() {
            @Override
            public void run() {
                scrollView.fullScroll(ScrollView.FOCUS_DOWN);
            }
        },250);
    }

}

