package com.example.rasmus.tryin.UI;

import android.util.SparseArray;
import android.util.SparseIntArray;

import java.util.HashMap;
import java.util.Map;

// Just a some place to some recipe information before the database i running
public class RecipeTest {
    private int idCounter = 0;
    private SparseIntArray imageID = new SparseIntArray();
    private SparseIntArray calorieCount = new SparseIntArray();
    private SparseArray<String> mealName = new SparseArray<>();

    public void addRecipe(int imgID, int calories, String meal){
        imageID.put(this.idCounter, imgID);
        calorieCount.put(this.idCounter, calories);
        mealName.put(this.idCounter, meal);
        idCounter++;
    }

    public int getCalories(int key){
        return calorieCount.get(key);

    }

    public int getImgID(int key){
        return imageID.get(key);
    }

    public String getMealName(int key){
        return mealName.get(key);
    }
}
