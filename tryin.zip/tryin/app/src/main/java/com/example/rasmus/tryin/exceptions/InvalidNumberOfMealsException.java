package com.example.rasmus.tryin.exceptions;

public class InvalidNumberOfMealsException extends RuntimeException {

}
